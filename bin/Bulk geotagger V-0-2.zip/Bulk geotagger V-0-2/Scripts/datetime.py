c#
import System
c#
dt = System.DateTime.Now
st = dt.ToString("yyyy-MM-ddTHH:mm:ss.fff") + ' setting wp 1'

# python
print st
# c#
System.Console.WriteLine(st)
